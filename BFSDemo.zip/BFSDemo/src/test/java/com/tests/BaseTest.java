package com.tests;

//import com.idp.pages.LoginPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseTest {
    protected WebDriver driver;
    @BeforeTest
    public void setupDriver(){
        //System.setProperty("webdriver.chrome.driver", "C:\\Users\\lc5638937\\OneDrive - FIS\\chrome_89\\chromedriver_win32\\chromedriver.exe");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\683132\\OneDrive - Cognizant\\chromedriver89\\chromedriver_win32\\chromedriver.exe");
        ChromeOptions options=new ChromeOptions();
        options.addArguments("--start-maximized");
        //DesiredCapabilities dc = DesiredCapabilities.chrome();
        DesiredCapabilities dc = new DesiredCapabilities();
        dc.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
        dc.setCapability(ChromeOptions.CAPABILITY, options);
        options.merge(dc);
        this.driver = new ChromeDriver(options);
        //this.driver = new ChromeDriver();
    }

    //write tests here

    @AfterTest
    public void quitDriver() throws InterruptedException {
        this.driver.quit();
    }
}
